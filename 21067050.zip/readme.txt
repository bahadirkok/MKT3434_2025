Machine Learning Training Interface
A PyQt6-based GUI application for experimenting with machine learning algorithms, featuring data loading, model training, and visualization capabilities.

Features
Data Management
Built-in datasets (Iris, Breast Cancer, MNIST, etc.)

Custom CSV file loading

Train-test split configuration

Data scaling (StandardScaler, MinMaxScaler, RobustScaler)

Machine Learning Algorithms
Classical ML
Regression: Linear Regression, Support Vector Machines (SVM)

Classification: Logistic Regression, Support Vector Machines (SVM), Decision Trees, Random Forest, Naive Bayes, K-Nearest Neighbors (KNN)

Deep Learning (TensorFlow/Keras)
MLP (Multilayer Perceptron) with customizable layers

CNN/RNN placeholders (future implementation)

Dimensionality Reduction
PCA (Principal Component Analysis)

K-Means Clustering

Model Evaluation
Regression Metrics: MSE (Mean Squared Error), MAE (Mean Absolute Error), Huber Loss, R² (R-Squared)

Classification Metrics: Accuracy, Confusion Matrix, Cross-Entropy, Hinge Loss

Visualization
Interactive Matplotlib and Plotly visualizations

Regression: Predicted vs Actual values

Classification: 2D/3D PCA projections, K-means clustering visualizations, t-SNE/UMAP projections

Installation
1. Prerequisites
Python 3.9.2 - 3.9.11 (recommended)

pip package manager

2. Install dependencies
Run the following command to install all the required dependencies:

bash
Kopyala
pip install PyQt6 numpy pandas scikit-learn matplotlib tensorflow-cpu
3. Basic Workflow
Select a dataset from the dropdown or load your own CSV file.

Choose preprocessing options (scaling, test split ratio).

Navigate to the algorithm tabs to configure model parameters (e.g., number of neighbors for KNN, kernel type for SVM).

Click "Train" to run the model on the selected data.

View results in the visualization panel, with the corresponding metrics displayed.

Troubleshooting
Common Issues:
TensorFlow Errors:

Ensure you have tensorflow-cpu installed if you don't have GPU support. Run the following commands to switch to the CPU version of TensorFlow:


pip uninstall tensorflow
pip install tensorflow-cpu
PyQt6 Compatibility:

Use Python 3.9.x for the best results with PyQt6. Ensure you are using the following compatible versions:

PyQt6==6.4.0
numpy==1.23.5
pandas==1.5.2
scikit-learn==1.2.0
matplotlib==3.6.2
tensorflow-cpu==2.11.0