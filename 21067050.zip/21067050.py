import sys
import numpy as np
import pandas as pd
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                           QHBoxLayout, QTabWidget, QPushButton, QLabel, 
                           QComboBox, QFileDialog, QSpinBox, QDoubleSpinBox,
                           QGroupBox, QScrollArea, QTextEdit, QStatusBar,
                           QProgressBar, QCheckBox, QGridLayout, QMessageBox,
                           QDialog, QLineEdit, QSlider)
from PyQt6.QtCore import Qt
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from sklearn import datasets, preprocessing, model_selection
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC, SVR
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import (mean_absolute_error, hinge_loss, log_loss,
                           accuracy_score, mean_squared_error, confusion_matrix,
                           silhouette_score, calinski_harabasz_score, davies_bouldin_score)
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.manifold import TSNE
from sklearn.model_selection import KFold
import umap
from mpl_toolkits.mplot3d import Axes3D
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers
from sklearn.preprocessing import LabelEncoder

class MLCourseGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Machine Learning Course GUI")
        self.setGeometry(100, 100, 1400, 900)
        
        # Initialize main widget and layout
        self.main_widget = QWidget()
        self.setCentralWidget(self.main_widget)
        self.layout = QVBoxLayout(self.main_widget)
        
        # Initialize data containers
        self.X_train = None
        self.X_val = None
        self.X_test = None
        self.y_train = None
        self.y_val = None
        self.y_test = None
        self.current_model = None
        self.layer_config = []
        self.plotly_figures = {}
        
        # Create components
        self.create_data_section()
        self.create_tabs()
        self.create_visualization()
        self.create_status_bar()

    def create_data_section(self):
        """Create the data loading and preprocessing section"""
        data_group = QGroupBox("Data Management")
        data_layout = QVBoxLayout()
        
        # Dataset selection
        dataset_layout = QHBoxLayout()
        dataset_layout.addWidget(QLabel("Dataset:"))
        self.dataset_combo = QComboBox()
        self.dataset_combo.addItems([
            "Load Custom Dataset",
            "Iris Dataset",
            "Breast Cancer Dataset",
            "Digits Dataset",
            "California Housing Dataset",
            "MNIST Dataset"
        ])
        self.dataset_combo.currentIndexChanged.connect(self.load_dataset)
        
        self.load_btn = QPushButton("Load Data")
        self.load_btn.clicked.connect(self.load_custom_data)
        
        dataset_layout.addWidget(self.dataset_combo)
        dataset_layout.addWidget(self.load_btn)
        data_layout.addLayout(dataset_layout)
        
        # Data splitting options
        split_group = QGroupBox("Data Splitting")
        split_layout = QGridLayout()
        
        # Train-Validation-Test split presets
        self.split_preset_combo = QComboBox()
        self.split_preset_combo.addItems([
            "Custom",
            "70-15-15 (Train-Val-Test)",
            "80-10-10 (Train-Val-Test)",
            "60-20-20 (Train-Val-Test)",
            "Traditional 80-20 (Train-Test)"
        ])
        self.split_preset_combo.currentIndexChanged.connect(self.update_split_ratios)
        
        # Custom split ratios
        self.train_ratio = QDoubleSpinBox()
        self.train_ratio.setRange(0.1, 0.9)
        self.train_ratio.setValue(0.7)
        self.train_ratio.setSingleStep(0.05)
        
        self.val_ratio = QDoubleSpinBox()
        self.val_ratio.setRange(0.0, 0.8)
        self.val_ratio.setValue(0.15)
        self.val_ratio.setSingleStep(0.05)
        
        self.test_ratio = QDoubleSpinBox()
        self.test_ratio.setRange(0.05, 0.8)
        self.test_ratio.setValue(0.15)
        self.test_ratio.setSingleStep(0.05)
        
        split_layout.addWidget(QLabel("Split Preset:"), 0, 0)
        split_layout.addWidget(self.split_preset_combo, 0, 1)
        split_layout.addWidget(QLabel("Train Ratio:"), 1, 0)
        split_layout.addWidget(self.train_ratio, 1, 1)
        split_layout.addWidget(QLabel("Validation Ratio:"), 2, 0)
        split_layout.addWidget(self.val_ratio, 2, 1)
        split_layout.addWidget(QLabel("Test Ratio:"), 3, 0)
        split_layout.addWidget(self.test_ratio, 3, 1)
        
        split_group.setLayout(split_layout)
        data_layout.addWidget(split_group)
        
        # Preprocessing options
        prep_group = QGroupBox("Preprocessing")
        prep_layout = QHBoxLayout()
        
        self.scaling_combo = QComboBox()
        self.scaling_combo.addItems([
            "No Scaling",
            "Standard Scaling",
            "Min-Max Scaling",
            "Robust Scaling"
        ])
        
        prep_layout.addWidget(QLabel("Scaling:"))
        prep_layout.addWidget(self.scaling_combo)
        prep_group.setLayout(prep_layout)
        data_layout.addWidget(prep_group)
        
        data_group.setLayout(data_layout)
        self.layout.addWidget(data_group)

    def update_split_ratios(self):
        preset = self.split_preset_combo.currentText()
        
        if preset == "70-15-15 (Train-Val-Test)":
            self.train_ratio.setValue(0.7)
            self.val_ratio.setValue(0.15)
            self.test_ratio.setValue(0.15)
        elif preset == "80-10-10 (Train-Val-Test)":
            self.train_ratio.setValue(0.8)
            self.val_ratio.setValue(0.1)
            self.test_ratio.setValue(0.1)
        elif preset == "60-20-20 (Train-Val-Test)":
            self.train_ratio.setValue(0.6)
            self.val_ratio.setValue(0.2)
            self.test_ratio.setValue(0.2)
        elif preset == "Traditional 80-20 (Train-Test)":
            self.train_ratio.setValue(0.8)
            self.val_ratio.setValue(0.0)
            self.test_ratio.setValue(0.2)

    def load_dataset(self):
        """Load selected dataset with train-val-test split"""
        try:
            dataset_name = self.dataset_combo.currentText()
            
            if dataset_name == "Load Custom Dataset":
                return
            
            if dataset_name == "Iris Dataset":
                data = datasets.load_iris()
            elif dataset_name == "Breast Cancer Dataset":
                data = datasets.load_breast_cancer()
            elif dataset_name == "Digits Dataset":
                data = datasets.load_digits()
            elif dataset_name == "California Housing Dataset":
                data = datasets.fetch_california_housing()
            elif dataset_name == "MNIST Dataset":
                (X_train, y_train), (X_test, y_test) = tf.keras.datasets.mnist.load_data()
                self.X_train, self.X_test = X_train, X_test
                self.y_train, self.y_test = y_train, y_test
                self.status_bar.showMessage(f"Loaded {dataset_name}")
                return
            
            # Get split ratios
            train_ratio = self.train_ratio.value()
            val_ratio = self.val_ratio.value()
            test_ratio = self.test_ratio.value()
            
            # First split into train+val and test
            X_train_val, X_test, y_train_val, y_test = model_selection.train_test_split(
                data.data, data.target, test_size=test_ratio, random_state=42)
            
            # Then split train+val into train and val
            if val_ratio > 0:
                val_ratio_adjusted = val_ratio / (train_ratio + val_ratio)
                X_train, X_val, y_train, y_val = model_selection.train_test_split(
                    X_train_val, y_train_val, test_size=val_ratio_adjusted, random_state=42)
            else:
                X_train, X_val, y_train, y_val = X_train_val, None, y_train_val, None
            
            # Store all splits
            self.X_train, self.X_val, self.X_test = X_train, X_val, X_test
            self.y_train, self.y_val, self.y_test = y_train, y_val, y_test
            
            # Apply scaling to all sets
            self.apply_scaling()
            
            self.status_bar.showMessage(
                f"Loaded {dataset_name} - Split: {train_ratio*100:.0f}%/{val_ratio*100:.0f}%/{test_ratio*100:.0f}%")
            
        except Exception as e:
            self.show_error(f"Error loading dataset: {str(e)}")

    def load_custom_data(self):
        """Load custom dataset from CSV file"""
        try:
            file_name, _ = QFileDialog.getOpenFileName(
                self,
                "Load Dataset",
                "",
                "CSV files (*.csv)"
            )
            
            if file_name:
                data = pd.read_csv(file_name)
                target_col = self.select_target_column(data.columns)
                
                if target_col:
                    X = data.drop(target_col, axis=1)
                    y = data[target_col]
                    
                    # Get split ratios
                    train_ratio = self.train_ratio.value()
                    val_ratio = self.val_ratio.value()
                    test_ratio = self.test_ratio.value()
                    
                    # First split into train+val and test
                    X_train_val, X_test, y_train_val, y_test = model_selection.train_test_split(
                        X, y, test_size=test_ratio, random_state=42)
                    
                    # Then split train+val into train and val
                    if val_ratio > 0:
                        val_ratio_adjusted = val_ratio / (train_ratio + val_ratio)
                        X_train, X_val, y_train, y_val = model_selection.train_test_split(
                            X_train_val, y_train_val, test_size=val_ratio_adjusted, random_state=42)
                    else:
                        X_train, X_val, y_train, y_val = X_train_val, None, y_train_val, None
                    
                    # Store all splits
                    self.X_train, self.X_val, self.X_test = X_train, X_val, X_test
                    self.y_train, self.y_val, self.y_test = y_train, y_val, y_test
                    
                    self.apply_scaling()
                    self.status_bar.showMessage(
                        f"Loaded custom dataset: {file_name} - Split: {train_ratio*100:.0f}%/{val_ratio*100:.0f}%/{test_ratio*100:.0f}%")
                    
        except Exception as e:
            self.show_error(f"Error loading custom dataset: {str(e)}")

    def select_target_column(self, columns):
        """Dialog to select target column from dataset"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Select Target Column")
        layout = QVBoxLayout(dialog)
        
        combo = QComboBox()
        combo.addItems(columns)
        layout.addWidget(combo)
        
        btn = QPushButton("Select")
        btn.clicked.connect(dialog.accept)
        layout.addWidget(btn)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            return combo.currentText()
        return None

    def apply_scaling(self):
        """Apply selected scaling method to all data splits"""
        scaling_method = self.scaling_combo.currentText()
        
        if scaling_method != "No Scaling":
            try:
                if scaling_method == "Standard Scaling":
                    scaler = preprocessing.StandardScaler()
                elif scaling_method == "Min-Max Scaling":
                    scaler = preprocessing.MinMaxScaler()
                elif scaling_method == "Robust Scaling":
                    scaler = preprocessing.RobustScaler()
                
                # Fit only on training data
                self.X_train = scaler.fit_transform(self.X_train)
                if self.X_val is not None:
                    self.X_val = scaler.transform(self.X_val)
                self.X_test = scaler.transform(self.X_test)
                
            except Exception as e:
                self.show_error(f"Error applying scaling: {str(e)}")

    def create_tabs(self):
        """Create tabs for different ML topics"""
        self.tab_widget = QTabWidget()
        
        tabs = [
            ("Classical ML", self.create_classical_ml_tab),
            ("Deep Learning", self.create_deep_learning_tab),
            ("Dimensionality Reduction", self.create_dim_reduction_tab),
            ("Reinforcement Learning", self.create_rl_tab)
        ]
        
        for tab_name, create_func in tabs:
            scroll = QScrollArea()
            tab_widget = create_func()
            scroll.setWidget(tab_widget)
            scroll.setWidgetResizable(True)
            self.tab_widget.addTab(scroll, tab_name)
        
        self.layout.addWidget(self.tab_widget)

    def create_classical_ml_tab(self):
        """Create the classical machine learning tab"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Placeholder content
        label = QLabel("Classical ML Algorithms (To be implemented)")
        layout.addWidget(label)
        
        return widget

    def create_deep_learning_tab(self):
        """Create the deep learning tab"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Placeholder content
        label = QLabel("Deep Learning Models (To be implemented)")
        layout.addWidget(label)
        
        return widget

    def create_rl_tab(self):
        """Create the reinforcement learning tab"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Placeholder content
        label = QLabel("Reinforcement Learning (To be implemented)")
        layout.addWidget(label)
        
        return widget

    def create_dim_reduction_tab(self):
        """Create the dimensionality reduction tab with enhanced features"""
        widget = QWidget()
        layout = QGridLayout(widget)

        # ===== Visualization Options =====
        viz_group = QGroupBox("Visualization Options")
        viz_layout = QHBoxLayout()
        
        self.viz_library_combo = QComboBox()
        self.viz_library_combo.addItems(["Matplotlib", "Plotly"])
        
        self.viz_3d_cb = QCheckBox("3D Visualization")
        self.viz_interactive_cb = QCheckBox("Interactive Mode")
        
        viz_layout.addWidget(QLabel("Library:"))
        viz_layout.addWidget(self.viz_library_combo)
        viz_layout.addWidget(self.viz_3d_cb)
        viz_layout.addWidget(self.viz_interactive_cb)
        
        viz_group.setLayout(viz_layout)
        layout.addWidget(viz_group, 0, 0, 1, 2)

        # ===== PCA Section =====
        pca_group = QGroupBox("Principal Component Analysis")
        pca_layout = QVBoxLayout()

        self.pca_n_components = QSpinBox()
        self.pca_n_components.setRange(1, 10)
        self.pca_n_components.setValue(2)
        
        self.pca_var_cb = QCheckBox("Show Explained Variance")
        self.pca_whiten = QCheckBox("Whiten")

        pca_layout.addWidget(QLabel("Number of components:"))
        pca_layout.addWidget(self.pca_n_components)
        pca_layout.addWidget(self.pca_var_cb)
        pca_layout.addWidget(self.pca_whiten)

        pca_btn = QPushButton("Run PCA")
        pca_btn.clicked.connect(self.run_pca)
        pca_layout.addWidget(pca_btn)

        pca_group.setLayout(pca_layout)
        layout.addWidget(pca_group, 1, 0)

        # ===== LDA Section =====
        lda_group = QGroupBox("Linear Discriminant Analysis")
        lda_layout = QVBoxLayout()

        self.lda_n_components = QSpinBox()
        self.lda_n_components.setRange(1, 10)
        self.lda_n_components.setValue(2)
        
        self.lda_metrics_cb = QCheckBox("Show Class Separation Metrics")

        lda_layout.addWidget(QLabel("Number of components:"))
        lda_layout.addWidget(self.lda_n_components)
        lda_layout.addWidget(self.lda_metrics_cb)

        lda_btn = QPushButton("Run LDA")
        lda_btn.clicked.connect(self.run_lda)
        lda_layout.addWidget(lda_btn)

        lda_group.setLayout(lda_layout)
        layout.addWidget(lda_group, 2, 0)

        # ===== K-Means Section =====
        kmeans_group = QGroupBox("K-Means Clustering")
        kmeans_layout = QVBoxLayout()

        cluster_row = QHBoxLayout()
        cluster_row.addWidget(QLabel("Number of clusters (2-50):"))
        self.kmeans_n_clusters = QSpinBox()
        self.kmeans_n_clusters.setRange(2, 50)
        self.kmeans_n_clusters.setValue(3)
        cluster_row.addWidget(self.kmeans_n_clusters)
        kmeans_layout.addLayout(cluster_row)

        # Options
        self.elbow_cb = QCheckBox("Show elbow method")
        self.silhouette_cb = QCheckBox("Show silhouette score")
        self.kmeans_3d_cb = QCheckBox("3D Visualization")

        kmeans_layout.addWidget(self.elbow_cb)
        kmeans_layout.addWidget(self.silhouette_cb)
        kmeans_layout.addWidget(self.kmeans_3d_cb)

        # Button
        kmeans_btn = QPushButton("Run K-Means")
        kmeans_btn.clicked.connect(self.run_kmeans)
        kmeans_layout.addWidget(kmeans_btn)

        kmeans_group.setLayout(kmeans_layout)
        layout.addWidget(kmeans_group, 1, 1)

        # ===== UMAP Section (Faster alternative to t-SNE) =====
        umap_group = QGroupBox("UMAP (Fast Dimensionality Reduction)")
        umap_layout = QVBoxLayout()

        self.umap_n_neighbors = QSpinBox()
        self.umap_n_neighbors.setRange(2, 200)
        self.umap_n_neighbors.setValue(15)
        
        self.umap_min_dist = QDoubleSpinBox()
        self.umap_min_dist.setRange(0.0, 1.0)
        self.umap_min_dist.setValue(0.1)
        
        self.umap_metric_combo = QComboBox()
        self.umap_metric_combo.addItems(["euclidean", "cosine", "manhattan", "correlation"])

        umap_layout.addWidget(QLabel("Number of neighbors:"))
        umap_layout.addWidget(self.umap_n_neighbors)
        umap_layout.addWidget(QLabel("Minimum distance:"))
        umap_layout.addWidget(self.umap_min_dist)
        umap_layout.addWidget(QLabel("Distance metric:"))
        umap_layout.addWidget(self.umap_metric_combo)

        umap_btn = QPushButton("Run UMAP")
        umap_btn.clicked.connect(self.run_umap)
        umap_layout.addWidget(umap_btn)

        umap_group.setLayout(umap_layout)
        layout.addWidget(umap_group, 2, 1)

        # ===== t-SNE Section =====
        tsne_group = QGroupBox("t-SNE")
        tsne_layout = QVBoxLayout()

        self.tsne_perplexity = QSlider(Qt.Orientation.Horizontal)
        self.tsne_perplexity.setRange(5, 50)
        self.tsne_perplexity.setValue(30)
        
        self.tsne_early_exaggeration = QDoubleSpinBox()
        self.tsne_early_exaggeration.setRange(1.0, 50.0)
        self.tsne_early_exaggeration.setValue(12.0)

        tsne_layout.addWidget(QLabel("Perplexity:"))
        tsne_layout.addWidget(self.tsne_perplexity)
        tsne_layout.addWidget(QLabel("Early Exaggeration:"))
        tsne_layout.addWidget(self.tsne_early_exaggeration)

        tsne_btn = QPushButton("Run t-SNE")
        tsne_btn.clicked.connect(self.run_tsne)
        tsne_layout.addWidget(tsne_btn)

        tsne_group.setLayout(tsne_layout)
        layout.addWidget(tsne_group, 3, 0)

        # ===== Clustering Quality Metrics =====
        metrics_group = QGroupBox("Clustering Quality Evaluation")
        metrics_layout = QVBoxLayout()
        
        self.cluster_metrics_combo = QComboBox()
        self.cluster_metrics_combo.addItems([
            "Silhouette Score", 
            "Calinski-Harabasz Index",
            "Davies-Bouldin Index"
        ])
        
        metrics_btn = QPushButton("Evaluate Clustering")
        metrics_btn.clicked.connect(self.evaluate_clustering)
        
        metrics_layout.addWidget(QLabel("Metric:"))
        metrics_layout.addWidget(self.cluster_metrics_combo)
        metrics_layout.addWidget(metrics_btn)
        
        metrics_group.setLayout(metrics_layout)
        layout.addWidget(metrics_group, 3, 1)

        # ===== Eigenvector Projection Section =====
        eigen_group = QGroupBox("Eigenvector Projection")
        eigen_layout = QVBoxLayout()

        eigen_btn = QPushButton("Compute Eigenvector Projection")
        eigen_btn.clicked.connect(self.run_eigenvector_projection)
        eigen_layout.addWidget(eigen_btn)

        eigen_group.setLayout(eigen_layout)
        layout.addWidget(eigen_group, 4, 0)

        # ===== Cross Validation Section =====
        cv_group = QGroupBox("Cross Validation")
        cv_layout = QVBoxLayout()

        self.cv_folds = QSpinBox()
        self.cv_folds.setRange(2, 20)
        self.cv_folds.setValue(5)
        
        self.cv_metrics_combo = QComboBox()
        self.cv_metrics_combo.addItems(["Accuracy", "MSE", "RMSE", "Silhouette Score"])

        cv_layout.addWidget(QLabel("Number of folds:"))
        cv_layout.addWidget(self.cv_folds)
        cv_layout.addWidget(QLabel("Metrics:"))
        cv_layout.addWidget(self.cv_metrics_combo)

        cv_btn = QPushButton("Run Cross Validation")
        cv_btn.clicked.connect(self.run_cross_validation)
        cv_layout.addWidget(cv_btn)

        cv_group.setLayout(cv_layout)
        layout.addWidget(cv_group, 4, 1)

        return widget

    def run_pca(self):
        """Run PCA with visualization options"""
        try:
            n_components = self.pca_n_components.value()
            whiten = self.pca_whiten.isChecked()
            
            pca = PCA(n_components=n_components, whiten=whiten)
            X_pca = pca.fit_transform(self.X_train)
            
            if self.pca_var_cb.isChecked():
                self.plot_explained_variance(pca)
            
            use_3d = self.viz_3d_cb.isChecked() and n_components >= 3
            n_components_vis = 3 if use_3d else 2
            
            if self.viz_library_combo.currentText() == "Plotly":
                self.plot_plotly(X_pca[:, :n_components_vis], "PCA Projection", n_components_vis, self.y_train)
            else:
                if use_3d:
                    self.plot_3d(X_pca[:, :3], "PCA Projection (3D)")
                else:
                    self.plot_2d(X_pca[:, :2], "PCA Projection")
                    
            # Show explained variance ratio
            variance_info = "\n".join([f"Component {i+1}: {ratio:.4f}" 
                                     for i, ratio in enumerate(pca.explained_variance_ratio_)])
            self.metrics_text.setText(f"PCA Results:\nExplained Variance Ratios:\n{variance_info}")
            
        except Exception as e:
            self.show_error(f"Error running PCA: {str(e)}")

    def run_lda(self):
        """Run LDA with class separation metrics and visualization options"""
        try:
            n_components = self.lda_n_components.value()
            
            lda = LinearDiscriminantAnalysis(n_components=n_components)
            X_lda = lda.fit_transform(self.X_train, self.y_train)
            
            if self.lda_metrics_cb.isChecked():
                class_means = lda.means_
                overall_mean = np.mean(class_means, axis=0)
                sb = np.sum([np.outer(m - overall_mean, m - overall_mean) 
                           for m in class_means], axis=0)
                separation = np.trace(sb)
                
                metrics_text = (f"LDA Class Separation Metrics:\n"
                              f"Between-class variance: {separation:.4f}\n"
                              f"Classes: {len(np.unique(self.y_train))}\n"
                              f"Components: {n_components}")
                self.metrics_text.setText(metrics_text)
            
            use_3d = self.viz_3d_cb.isChecked() and n_components >= 3
            n_components_vis = 3 if use_3d else 2
            
            if self.viz_library_combo.currentText() == "Plotly":
                self.plot_plotly(X_lda[:, :n_components_vis], "LDA Projection", n_components_vis, self.y_train)
            else:
                if use_3d:
                    self.plot_3d(X_lda[:, :3], "LDA Projection (3D)")
                else:
                    self.plot_2d(X_lda[:, :2], "LDA Projection")
                
        except Exception as e:
            self.show_error(f"Error running LDA: {str(e)}")

    def run_kmeans(self):
        """Run K-Means with elbow method and silhouette score options"""
        try:
            n_clusters = self.kmeans_n_clusters.value()
            
            if self.elbow_cb.isChecked():
                self.plot_kmeans_elbow()
                return
                
            kmeans = KMeans(n_clusters=n_clusters)
            labels = kmeans.fit_predict(self.X_train)
            
            if self.silhouette_cb.isChecked():
                silhouette_avg = silhouette_score(self.X_train, labels)
                self.metrics_text.setText(f"K-Means Results:\n"
                                        f"Silhouette Score: {silhouette_avg:.4f}\n"
                                        f"Inertia: {kmeans.inertia_:.4f}")
            
            # Use PCA for visualization if needed
            if self.X_train.shape[1] > 2:
                pca = PCA(n_components=3 if self.kmeans_3d_cb.isChecked() else 2)
                X_vis = pca.fit_transform(self.X_train)
            else:
                X_vis = self.X_train
                
            if self.kmeans_3d_cb.isChecked() and X_vis.shape[1] >= 3:
                # Ensure we have enough dimensions for 3D
                if X_vis.shape[1] < 3:
                    X_vis = np.hstack([X_vis, np.zeros((X_vis.shape[0], 3 - X_vis.shape[1]))])
                
                if self.viz_library_combo.currentText() == "Plotly":
                    self.plot_plotly(X_vis[:, :3], "K-Means Clustering", 3, labels)
                else:
                    self.plot_3d(X_vis[:, :3], "K-Means Clustering (3D)", labels)
            else:
                if self.viz_library_combo.currentText() == "Plotly":
                    self.plot_plotly(X_vis[:, :2], "K-Means Clustering", 2, labels)
                else:
                    self.plot_2d(X_vis[:, :2], "K-Means Clustering", labels)
                    
        except Exception as e:
            self.show_error(f"Error running K-Means: {str(e)}")

    def run_tsne(self):
        """Run t-SNE with configurable perplexity and visualization options"""
        try:
            perplexity = self.tsne_perplexity.value()
            early_exaggeration = self.tsne_early_exaggeration.value()
            n_components = 3 if self.viz_3d_cb.isChecked() else 2
            
            tsne = TSNE(n_components=n_components,
                        perplexity=perplexity,
                        early_exaggeration=early_exaggeration)
            X_tsne = tsne.fit_transform(self.X_train)
            
            if self.viz_library_combo.currentText() == "Plotly":
                self.plot_plotly(X_tsne, "t-SNE Projection", n_components, self.y_train)
            else:
                if n_components == 3:
                    self.plot_3d(X_tsne, "t-SNE Projection (3D)")
                else:
                    self.plot_2d(X_tsne, "t-SNE Projection")
                
        except Exception as e:
            self.show_error(f"Error running t-SNE: {str(e)}")

    def run_umap(self):
        """Run UMAP with configurable parameters and visualization options"""
        try:
            n_neighbors = self.umap_n_neighbors.value()
            min_dist = self.umap_min_dist.value()
            metric = self.umap_metric_combo.currentText()
            n_components = 3 if self.viz_3d_cb.isChecked() else 2
            
            reducer = umap.UMAP(
                n_neighbors=n_neighbors,
                min_dist=min_dist,
                n_components=n_components,
                metric=metric,
                random_state=42
            )
            X_umap = reducer.fit_transform(self.X_train)
            
            if self.viz_library_combo.currentText() == "Plotly":
                self.plot_plotly(X_umap, "UMAP Projection", n_components, self.y_train)
            else:
                if n_components == 3:
                    self.plot_3d(X_umap, "UMAP Projection (3D)")
                else:
                    self.plot_2d(X_umap, "UMAP Projection")
                    
            self.metrics_text.append(f"\nUMAP completed with {n_neighbors} neighbors and {min_dist} min distance")
            
        except Exception as e:
            self.show_error(f"Error running UMAP: {str(e)}")

    def evaluate_clustering(self):
        """Evaluate clustering quality using selected metrics"""
        try:
            if not hasattr(self, 'X_train'):
                raise ValueError("Please load data first")
                
            metric = self.cluster_metrics_combo.currentText()
            
            # For demonstration, we'll use KMeans with default clusters
            kmeans = KMeans(n_clusters=3)
            labels = kmeans.fit_predict(self.X_train)
            
            if metric == "Silhouette Score":
                score = silhouette_score(self.X_train, labels)
                interpretation = """
                Silhouette Score Interpretation:
                +1: Perfect clustering
                 0: Overlapping clusters
                -1: Completely wrong clustering
                """
            elif metric == "Calinski-Harabasz Index":
                score = calinski_harabasz_score(self.X_train, labels)
                interpretation = """
                Calinski-Harabasz Index:
                Higher values indicate better clustering
                Measures ratio of between-cluster dispersion to within-cluster dispersion
                """
            elif metric == "Davies-Bouldin Index":
                score = davies_bouldin_score(self.X_train, labels)
                interpretation = """
                Davies-Bouldin Index:
                Lower values indicate better clustering
                Measures average similarity between clusters
                """
                
            self.metrics_text.setText(
                f"Clustering Evaluation:\n"
                f"Metric: {metric}\n"
                f"Score: {score:.4f}\n\n"
                f"Interpretation:{interpretation}"
            )
            
        except Exception as e:
            self.show_error(f"Error evaluating clustering: {str(e)}")

    def run_eigenvector_projection(self):
        """Compute eigenvectors for given covariance matrix and project data"""
        try:
            # Given covariance matrix
            Σ = np.array([[5, 2], [2, 3]])
            
            # Compute eigenvalues and eigenvectors
            eigenvalues, eigenvectors = np.linalg.eig(Σ)
            
            # Project data to 1D using dominant eigenvector
            projection_vector = eigenvectors[:, np.argmax(eigenvalues)]
            projected_data = self.X_train.dot(projection_vector)
            
            if self.viz_library_combo.currentText() == "Plotly":
                fig = go.Figure(data=[go.Scatter(
                    x=projected_data,
                    y=np.zeros_like(projected_data),
                    mode='markers',
                    marker=dict(
                        size=8,
                        color=self.y_train,
                        colorscale='Viridis',
                        opacity=0.8
                    )
                )])
                fig.update_layout(
                    title="1D Projection via Eigenvector",
                    xaxis_title="Projection onto Dominant Eigenvector",
                    yaxis=dict(showticklabels=False, title="")
                )
                fig.show()
            else:
                # Plot the projection
                self.figure.clear()
                ax = self.figure.add_subplot(111)
                ax.scatter(projected_data, np.zeros_like(projected_data), c=self.y_train)
                ax.set_title("1D Projection via Eigenvector")
                ax.set_yticks([])
                ax.set_xlabel("Projection onto Dominant Eigenvector")
                self.canvas.draw()
            
            # Show eigenvalues and eigenvectors
            self.metrics_text.setText(
                f"Eigenvalues: {eigenvalues}\n"
                f"Eigenvectors:\n{eigenvectors}\n\n"
                f"1D Projection Vector:\n{projection_vector}"
            )
            
        except Exception as e:
            self.show_error(f"Error computing eigenvector projection: {str(e)}")

    def run_cross_validation(self):
        """Run k-fold cross validation with selected metrics"""
        try:
            k = self.cv_folds.value()
            metric = self.cv_metrics_combo.currentText()
            
            if metric == "Silhouette Score":
                # For clustering evaluation
                kmeans = KMeans(n_clusters=self.kmeans_n_clusters.value())
                scores = []
                
                kf = KFold(n_splits=k)
                for train_index, _ in kf.split(self.X_train):
                    X_fold = self.X_train[train_index]
                    kmeans.fit(X_fold)
                    scores.append(silhouette_score(X_fold, kmeans.labels_))
                
                self.metrics_text.setText(
                    f"Silhouette Scores (k={k}):\n"
                    f"Mean: {np.mean(scores):.4f}\n"
                    f"Std: {np.std(scores):.4f}\n"
                    f"All scores: {scores}"
                )
            else:
                # For supervised learning
                model = LinearDiscriminantAnalysis()  # Default model for demo
                scores = []
                
                kf = KFold(n_splits=k)
                for train_index, test_index in kf.split(self.X_train):
                    X_train_fold, X_test_fold = self.X_train[train_index], self.X_train[test_index]
                    y_train_fold, y_test_fold = self.y_train[train_index], self.y_train[test_index]
                    
                    model.fit(X_train_fold, y_train_fold)
                    y_pred = model.predict(X_test_fold)
                    
                    if metric == "Accuracy":
                        scores.append(accuracy_score(y_test_fold, y_pred))
                    elif metric == "MSE":
                        scores.append(mean_squared_error(y_test_fold, y_pred))
                    elif metric == "RMSE":
                        scores.append(np.sqrt(mean_squared_error(y_test_fold, y_pred)))
                
                self.metrics_text.setText(
                    f"{metric} Scores (k={k}):\n"
                    f"Mean: {np.mean(scores):.4f}\n"
                    f"Std: {np.std(scores):.4f}\n"
                    f"All scores: {scores}"
                )
                
        except Exception as e:
            self.show_error(f"Error in cross validation: {str(e)}")

    def plot_explained_variance(self, pca):
        """Plot PCA explained variance ratio"""
        if self.viz_library_combo.currentText() == "Plotly":
            fig = go.Figure(data=[go.Bar(
                x=[f"PC{i+1}" for i in range(len(pca.explained_variance_ratio_))],
                y=pca.explained_variance_ratio_
            )])
            fig.update_layout(
                title="Explained Variance by Components",
                xaxis_title="Principal Component",
                yaxis_title="Explained Variance Ratio"
            )
            fig.show()
        else:
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            ax.bar(range(len(pca.explained_variance_ratio_)), 
                  pca.explained_variance_ratio_)
            ax.set_title('Explained Variance by Components')
            ax.set_xlabel('Principal Component')
            ax.set_ylabel('Explained Variance Ratio')
            self.canvas.draw()

    def plot_kmeans_elbow(self):
        """Plot elbow method for K-Means"""
        inertias = []
        for k in range(2, 11):
            kmeans = KMeans(n_clusters=k)
            kmeans.fit(self.X_train)
            inertias.append(kmeans.inertia_)
            
        if self.viz_library_combo.currentText() == "Plotly":
            fig = go.Figure(data=[go.Scatter(
                x=list(range(2, 11)),
                y=inertias,
                mode='lines+markers'
            )])
            fig.update_layout(
                title='Elbow Method for Optimal K',
                xaxis_title='Number of clusters',
                yaxis_title='Inertia'
            )
            fig.show()
        else:
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            ax.plot(range(2, 11), inertias, 'bx-')
            ax.set_xlabel('Number of clusters')
            ax.set_ylabel('Inertia')
            ax.set_title('Elbow Method for Optimal K')
            self.canvas.draw()

    def plot_2d(self, data, title, colors=None):
        """Generic 2D projection plot"""
        if colors is None:
            colors = self.y_train
            
        if self.viz_library_combo.currentText() == "Plotly":
            self.plot_plotly(data, title, 2, colors)
        else:
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            scatter = ax.scatter(data[:, 0], data[:, 1], c=colors, cmap='viridis')
            ax.set_title(title)
            ax.set_xlabel('Component 1')
            ax.set_ylabel('Component 2')
            self.figure.colorbar(scatter)
            self.canvas.draw()

    def plot_3d(self, data, title, colors=None):
        """Generic 3D projection plot"""
        if colors is None:
            colors = self.y_train
            
        if self.viz_library_combo.currentText() == "Plotly":
            self.plot_plotly(data, title, 3, colors)
        else:
            self.figure.clear()
            ax = self.figure.add_subplot(111, projection='3d')
            scatter = ax.scatter(data[:, 0], data[:, 1], data[:, 2], c=colors, cmap='viridis')
            ax.set_title(title)
            ax.set_xlabel('Component 1')
            ax.set_ylabel('Component 2')
            ax.set_zlabel('Component 3')
            self.figure.colorbar(scatter)
            self.canvas.draw()

    def plot_plotly(self, data, title, n_components, colors=None):
        """Create interactive Plotly visualization"""
        try:
            if colors is None:
                colors = self.y_train
                
            # Convert colors to numeric if they're strings
            if isinstance(colors[0], str):
                le = LabelEncoder()
                colors = le.fit_transform(colors)
            
            if n_components == 3:
                fig = go.Figure(data=[go.Scatter3d(
                    x=data[:, 0],
                    y=data[:, 1],
                    z=data[:, 2],
                    mode='markers',
                    marker=dict(
                        size=5,
                        color=colors,
                        colorscale='Viridis',
                        opacity=0.8,
                        colorbar=dict(title='Class')
                    ),
                    hovertext=[f"Class: {c}" for c in self.y_train]
                )])
                fig.update_layout(
                    title=title + " (3D)",
                    scene=dict(
                        xaxis_title='Component 1',
                        yaxis_title='Component 2',
                        zaxis_title='Component 3'
                    )
                )
            else:
                fig = go.Figure(data=[go.Scatter(
                    x=data[:, 0],
                    y=data[:, 1],
                    mode='markers',
                    marker=dict(
                        size=8,
                        color=colors,
                        colorscale='Viridis',
                        opacity=0.8,
                        colorbar=dict(title='Class')
                    ),
                    hovertext=[f"Class: {c}" for c in self.y_train]
                )])
                fig.update_layout(
                    title=title,
                    xaxis_title='Component 1',
                    yaxis_title='Component 2'
                )
            
            # Show in browser
            fig.show()
            self.metrics_text.append(f"\nPlotly {title} visualization opened in browser")
            
        except Exception as e:
            self.show_error(f"Error creating Plotly visualization: {str(e)}")

    def create_visualization(self):
        """Create the visualization section"""
        viz_group = QGroupBox("Visualization")
        viz_layout = QHBoxLayout()
        
        # Create matplotlib figure
        self.figure = Figure(figsize=(8, 6))
        self.canvas = FigureCanvas(self.figure)
        viz_layout.addWidget(self.canvas)
        
        # Metrics display
        self.metrics_text = QTextEdit()
        self.metrics_text.setReadOnly(True)
        viz_layout.addWidget(self.metrics_text)
        
        viz_group.setLayout(viz_layout)
        self.layout.addWidget(viz_group)

    def create_status_bar(self):
        """Create the status bar"""
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        
        # Add progress bar
        self.progress_bar = QProgressBar()
        self.status_bar.addPermanentWidget(self.progress_bar)

    def show_error(self, message):
        """Show error message dialog"""
        QMessageBox.critical(self, "Error", message)

def main():
    """Main function to start the application"""
    app = QApplication(sys.argv)
    window = MLCourseGUI()
    window.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()